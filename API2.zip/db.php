 <?php
  session_start();
  $db = new mysqli("localhost","root","1234","eye", 3306);
  $db->set_charset("utf8");
  function mq($sql){
    global $db;
    return $db->query($sql);
  }
?>