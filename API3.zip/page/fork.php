<?php
    include "../db.php";
    $code = $_GET["code"];
    $ch = curl_init("https://kauth.kakao.com/oauth/token");

    $data = array(
        "grant_type"=>"authorization_code",
        "client_id"=>"83ea5491ab36d7b5bf7e8d92f1828911",
        "code"=>$code,
        "client_secret"=>"RqYAeYhYpeiDhObI1XO5EyX0xO8OApfH"
    );
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));

    $output = curl_exec($ch);
    $errors = curl_error($ch);
    $response = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $token=json_decode($output,true)[access_token];
    curl_close($ch);

        $ch = curl_init("https://kapi.kakao.com/v2/user/me");
        $header = array(
            'Authorization: Bearer '.$token
        );
        $data = http_build_query(array(
            "property_keys"=>["kakao_account.id"]
        ));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $header);

    $response = curl_exec($ch);

    $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);

    $header = substr($response, 0, $header_size);
    $body = substr($response, $header_size);

    $id = json_decode($body, true);
    $sql = mq("select count(*) as cnt from users where id = ".$id[id]);
    $res = $sql->fetch_array();
    if($res[cnt]==1){
        echo '<script>location.href="main.php?code='.$code.'&id='.$id[id].'"</script>';
    }
    else{
        echo '<script>location.href="../member/signup.php?id='.$id[id].'"</script>';
    }
?>
