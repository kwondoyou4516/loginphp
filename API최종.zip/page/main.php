<?php
    include '../db.php';
    $id = $_GET['id'];
    $who = mq("select * from users where id ='".$id."';");
    $res = $who->fetch_array();

    $name = $res['nickname'];
    $point = $res['point'];
    echo '<script>alert("'.$name.'님의 남은 포인트는 '.$point.'입니다")</script>';
?>

<head>
	<meta charset="utf-8" />
	<title>메인페이지</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@1.3.1/dist/tf.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@teachablemachine/image@0.8/dist/teachablemachine-image.min.js"></script>
    <script src="https://developers.kakao.com/sdk/js/kakao.js"></script>
    <script>
        let point = 0;
        let mini = 600;
        function plus(amount){
            mini += amount * 60;
            if(mini<0){
                mini=0;
            }
            $("#minutes").text(mini/60+" : 00");
        }
        function startTimer() {
            point = mini/60;
            $("#webcam-container").show();
            $("#label-container").show();
            let min = 0;
            let sec = 0;
            let x = setInterval(function () {
                min = Math.floor(mini / 60);
                sec = mini % 60;
                let txt=min + " : ";
                if(sec<10){
                    txt=txt+"0";
                }
                $("#minutes").text(txt+sec);
                mini--;
                if (mini < 0) {
                    mini=0;
                    clearInterval(x);
                    $("#webcam-container").hide();
                    $("#label-container").hide();
                    alert("타이머 종료");
                    $("#demo").text("끝");
                }
            }, 1000);
        }
    </script>
    <script src="https://unpkg.com/axios/dist/axios.min.js"></script>
    <script>

        const URL = "../my_model (1)/";
        let model, webcam, labelContainer, maxPredictions;

        async function init() {

            const modelURL = URL + "model.json";
            const metadataURL = URL + "metadata.json";

            model = await tmImage.load(modelURL, metadataURL);
            maxPredictions = model.getTotalClasses();

            const flip = true; // whether to flip the webcam
            webcam = new tmImage.Webcam(200, 200, flip); // width, height, flip
            await webcam.setup(); // request access to the webcam
            await webcam.play();
            window.requestAnimationFrame(loop);

            document.getElementById("webcam-container").appendChild(webcam.canvas);
            labelContainer = document.getElementById("label-container");
        }
        async function loop() {
            webcam.update(); // update the webcam frame
            await predict();
            window.requestAnimationFrame(loop);
        }
        let frown=0;
        let total=100;
        // run the webcam image through the image model
        async function predict() {
            // predict can take in an image, video or canvas html element
            const prediction = await model.predict(webcam.canvas);

            if (prediction[0].className == "basic" && prediction[0].probability.toFixed(2) > 0.80) {
                $("#label-container").html("자세를 유지하세요");
                total++;
            } else if (prediction[1].className == "Frown" && prediction[1].probability.toFixed(2) > 0.80) {
                $("#label-container").html("찌푸리지 말아요!");
                frown++;total++;
            } else if (prediction[2].className == "close" && prediction[2].probability.toFixed(2) > 0.80) {
                $("#label-container").html("가까이 보지 마세요!");
                frown++;total++;
            } else if (prediction[3].className == "squint" && prediction[3].probability.toFixed(2) > 0.80) {
                $("#label-container").html("곁눈질은 나빠요");
                frown++;total++;
            } else {
                $("#label-container").html("인식 안됨");
            }
            console.log("frown : "+frown+"total : "+total);
            if(frown/total>0.4){
                alert("안과를 가보세요");
                let accessCode = '<?php echo $_GET["code"]?>';
                location.href = "../sendAlarm.php?code="+accessCode;
                frown = 0;
                total = 100;
            }
        }
    </script>

</head>
<body>
    <div class="container">
        <div class="row justify-content-center" style="height: 200px">
            <div id="webcam-container"></div>
        </div>
        <div class="row justify-content-center" style="height: 40px;margin-top: 10px">
            <h2 id="label-container"></h2>
        </div>
        <div class="row justify-content-center">
            <h1 class="display-1" id="minutes">10 : 00</h1>
        </div>
        <div class="row justify-content-center">
            <div class="btn-group" role="group" aria-label="changeTime" style = "width: 250px">
                <button type="button" class="btn btn-secondary" onclick="plus(1)">+1분</button>
                <button type="button" class="btn btn-secondary" onclick="plus(-1)">-1분</button>
                <button type="button" class="btn btn-secondary" onclick="plus(5)">+5분</button>
                <button type="button" class="btn btn-secondary" onclick="plus(-5)">-5분</button>
            </div>
        </div>
        <div class="row justify-content-center">
            <button type="button" class="btn btn-success mbtn" style = "width: 250px; margin-top:20px" onclick="startTimer();init()">시작</button>
        </div>
        <script>
            let url = '../member/logout.php?id=';
            let id = '<?php echo $id; ?>';
            let bd= url + id;
        </script>
        <div class="row justify-content-center">
            <button type="button" class="btn btn-warning mbtn" style = "width: 250px; margin-top:40px" onclick="location.href = bd">로그아웃</button>
        </div>
    </div>
</body>
