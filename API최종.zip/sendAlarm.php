<?php
    $code = $_GET["code"];
    $ch = curl_init("https://kauth.kakao.com/oauth/token");

    $data = array(
        "grant_type"=>"authorization_code",
        "client_id"=>"83ea5491ab36d7b5bf7e8d92f1828911",
        "code"=>$code,
        "client_secret"=>"RqYAeYhYpeiDhObI1XO5EyX0xO8OApfH"
    );
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));

    $output = curl_exec($ch);
    $errors = curl_error($ch);
    $response = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $token=json_decode($output,true);
    curl_close($ch);

    $ch = curl_init("https://kapi.kakao.com/v2/api/talk/memo/send?template_id=39132");

    curl_setopt($ch, CURLOPT_HEADER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Authorization: Bearer '.$token[access_token]
    ));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    $output = curl_exec($ch);
    $errors = curl_error($ch);
    $response = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close(ch);
    echo '<script>history.back()</script>';
?>