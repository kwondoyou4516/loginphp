<?php
	include "../db.php";
    $time = $_GET['time'];
    $id = $_GET['id'];
    $sql=mq("UPDATE users SET point = point + 10 WHERE id=".$id);

	session_destroy();
?>
<meta charset="utf-8">
<script>alert("로그아웃되었습니다."); location.href="/"; </script>