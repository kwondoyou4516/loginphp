<?php
	include "../db.php";
	include "../password.php";
	$id = $_GET['id'];
	$email = $_POST['email'];
	$nickname = $_POST['nickname'];
	$sql = mq("insert into users (id, email, nickname, point) VALUES ('".$id."', '".$email."', '".$nickname."', 0)");
	?>
<meta charset="utf-8" />
<script type="text/javascript">alert('회원가입이 완료되었습니다.');</script>
<meta http-equiv="refresh" content="0 url=/">